package pl.sginko.travelallowance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelAllowanceCalculationApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelAllowanceCalculationApplication.class, args);
	}

}
